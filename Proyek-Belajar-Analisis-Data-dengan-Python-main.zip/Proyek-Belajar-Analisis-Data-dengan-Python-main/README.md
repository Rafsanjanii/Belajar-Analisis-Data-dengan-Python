# Dicoding Collection Dashboard ✨

## Setup Environment - Anaconda
```
conda create --name main-ds python=3.9
conda activate main-ds
pip install numpy pandas scipy matplotlib seaborn jupyter streamlit babel
```

## Run steamlit app
```
streamlit run app.py
```

link : https://3dktsysnzw6nibabctrjqz.streamlit.app/

![image](https://github.com/brianketaren14/Proyek-Belajar-Analisis-Data-dengan-Python/assets/86067355/192a7418-93d8-460c-8181-38c866157d0f)


